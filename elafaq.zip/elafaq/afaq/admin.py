from django.contrib import admin
from .models import lecture,notfication,questions


admin.site.register(lecture)
admin.site.register(notfication)
admin.site.register(questions)
# Register your models here.
